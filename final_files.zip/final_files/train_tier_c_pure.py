import pandas as pd
import numpy as np
import xgboost as xgb
from sklearn.metrics import accuracy_score, f1_score, classification_report
from sklearn.model_selection import train_test_split
from sklearn.utils.class_weight import compute_sample_weight
from onnxmltools import convert_xgboost
from onnxmltools.convert.common.data_types import FloatTensorType
import json
import logging
from pathlib import Path

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(message)s')

def train_tier_c_pure():
    DATA_PATH = Path.cwd() / "pure_cicids2017.parquet"
    MAP_PATH = Path.cwd() / "universal_label_map.json"

    logging.info("Loading universal label map...")
    with open(MAP_PATH, 'r') as f:
        label_map = json.load(f)

    logging.info("Loading PURE dataset...")
    df_full = pd.read_parquet(DATA_PATH)

    df_full['Label'] = df_full['Label'].str.replace(r'Web Attack.*Brute Force', 'Web Attack - Brute Force', regex=True)
    df_full['Label'] = df_full['Label'].str.replace(r'Web Attack.*Sql Injection', 'Web Attack - Sql Injection', regex=True)
    df_full['Label'] = df_full['Label'].str.replace(r'Web Attack.*XSS', 'Web Attack - XSS', regex=True)

    y_full = df_full['Label'].map(label_map).values
    y_full = y_full.astype(np.int64)

    X_full = df_full.drop(columns=['Label'])
    cols_to_drop = [c for c in X_full.columns if 'Unnamed' in str(c) or 'index' in str(c).lower() or '__' in str(c)]
    X_full = X_full.drop(columns=cols_to_drop)
    if X_full.shape[1] > 78: 
        X_full = X_full.iloc[:, -78:]
        
    # THE FIX: Added .values to strip text column names so ONNX doesn't crash
    X_full_array = X_full.values.astype(np.float32)

    logging.info("Splitting data 80/20...")
    X_train, X_test, y_train, y_test = train_test_split(
        X_full_array, y_full, test_size=0.2, stratify=y_full, random_state=42
    )

    logging.info("Calculating sample weights for extreme class imbalance...")
    sample_weights = compute_sample_weight(class_weight='balanced', y=y_train)

    logging.info("Training Tier C (Heavy XGBoost Multi-class)...")
    model = xgb.XGBClassifier(
        objective='multi:softmax',
        num_class=15,
        tree_method='hist', 
        n_estimators=150,   
        max_depth=12,       
        learning_rate=0.05,
        random_state=42,
        n_jobs=-1
    )
    
    model.fit(X_train, y_train, sample_weight=sample_weights)

    logging.info("Evaluating real-world performance...")
    preds = model.predict(X_test)
    acc = accuracy_score(y_test, preds)
    macro_f1 = f1_score(y_test, preds, average='macro')
    
    print("\n" + "="*50)
    print(f"🧠 TIER C (XGBoost) PURE PERFORMANCE")
    print("="*50)
    print(f"Accuracy:  {acc:.4f}")
    print(f"Macro F1:  {macro_f1:.4f}")
    print("-" * 50)
    
    target_names = [k for k, v in sorted(label_map.items(), key=lambda item: item[1])]
    print(classification_report(y_test, preds, target_names=target_names, zero_division=0))
    print("="*50 + "\n")

    logging.info("Training final Tier C on 100% of data...")
    final_weights = compute_sample_weight(class_weight='balanced', y=y_full)
    
    final_model = xgb.XGBClassifier(
        objective='multi:softmax', num_class=15, tree_method='hist',
        n_estimators=150, max_depth=12, learning_rate=0.05, random_state=42, n_jobs=-1
    )
    final_model.fit(X_full_array, y_full, sample_weight=final_weights)

    logging.info("Exporting XGBoost to ONNX...")
    initial_type = [('float_input', FloatTensorType([None, 78]))]
    onnx_model = convert_xgboost(final_model, initial_types=initial_type)
    
    out_path = Path.cwd() / "tier_c_xgboost_pure.onnx"
    with open(out_path, "wb") as f:
        f.write(onnx_model.SerializeToString())
        
    logging.info(f"✅ Pure Tier C ONNX saved to {out_path}")

if __name__ == '__main__':
    train_tier_c_pure()