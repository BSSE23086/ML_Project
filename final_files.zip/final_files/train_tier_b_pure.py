import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score, classification_report
from sklearn.model_selection import train_test_split
from skl2onnx import convert_sklearn
from skl2onnx.common.data_types import FloatTensorType
import json
import logging
from pathlib import Path

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(message)s')

def train_tier_b_pure():
    DATA_PATH = Path.cwd() / "pure_cicids2017.parquet"
    MAP_PATH = Path.cwd() / "universal_label_map.json"

    logging.info("Loading universal label map...")
    try:
        with open(MAP_PATH, 'r') as f:
            label_map = json.load(f)
    except FileNotFoundError:
        logging.error("universal_label_map.json not found! Please create it first.")
        return

    logging.info("Loading PURE dataset...")
    df_full = pd.read_parquet(DATA_PATH)

    # ==========================================
    # THE FIX: Bulletproof Regex replacement for corrupted "Web Attack" strings
    # ==========================================
    df_full['Label'] = df_full['Label'].str.replace(r'Web Attack.*Brute Force', 'Web Attack - Brute Force', regex=True)
    df_full['Label'] = df_full['Label'].str.replace(r'Web Attack.*Sql Injection', 'Web Attack - Sql Injection', regex=True)
    df_full['Label'] = df_full['Label'].str.replace(r'Web Attack.*XSS', 'Web Attack - XSS', regex=True)

    # 1. Map labels safely
    y_full = df_full['Label'].map(label_map).values
    
    # SAFETY CHECK: If there are still NaNs, tell us exactly what strings are failing
    if np.isnan(y_full).any():
        missing_labels = df_full[df_full['Label'].map(label_map).isna()]['Label'].unique()
        logging.error(f"FATAL: The following labels are in the data but NOT in your JSON map: {missing_labels}")
        return
        
    y_full = y_full.astype(np.int64) # Force integer type to prevent PyTorch/Sklearn clashes

    # 2. Drop Label column and enforce 78 features exactly
    X_full = df_full.drop(columns=['Label'])
    cols_to_drop = [c for c in X_full.columns if 'Unnamed' in str(c) or 'index' in str(c).lower() or '__' in str(c)]
    X_full = X_full.drop(columns=cols_to_drop)
    if X_full.shape[1] > 78: 
        X_full = X_full.iloc[:, -78:]
        
    X_full = X_full.astype(np.float32)

    logging.info("Splitting 80/20 for rigorous evaluation...")
    X_train, X_test, y_train, y_test = train_test_split(
        X_full, y_full, test_size=0.2, stratify=y_full, random_state=42
    )

    logging.info("Training Tier B (Random Forest) on pure data...")
    # class_weight='balanced' forces the AI to hunt rare attacks
    model = RandomForestClassifier(
        n_estimators=75, 
        max_depth=25, 
        class_weight='balanced', 
        n_jobs=-1, 
        random_state=42
    )
    model.fit(X_train, y_train)

    logging.info("Evaluating real-world performance...")
    preds = model.predict(X_test)
    acc = accuracy_score(y_test, preds)
    macro_f1 = f1_score(y_test, preds, average='macro')
    
    print("\n" + "="*50)
    print(f"🛡️ TIER B PURE PERFORMANCE (NO LEAKS)")
    print("="*50)
    print(f"Accuracy:  {acc:.4f}")
    print(f"Macro F1:  {macro_f1:.4f} <--- The TRUE Score!")
    print("-" * 50)
    
    # Re-order the target names based on their integer mapping
    target_names = [k for k, v in sorted(label_map.items(), key=lambda item: item[1])]
    print(classification_report(y_test, preds, target_names=target_names, zero_division=0))
    print("="*50 + "\n")

    logging.info("Training final model on 100% of pure data for deployment...")
    final_model = RandomForestClassifier(
        n_estimators=75, max_depth=25, class_weight='balanced', n_jobs=-1, random_state=42
    )
    final_model.fit(X_full, y_full)

    logging.info("Exporting to ONNX...")
    initial_type = [('float_input', FloatTensorType([None, X_full.shape[1]]))]
    onnx_model = convert_sklearn(final_model, initial_types=initial_type, target_opset=12)
    
    out_path = Path.cwd() / "tier_b_rf_pure.onnx"
    with open(out_path, "wb") as f:
        f.write(onnx_model.SerializeToString())
        
    logging.info(f"✅ Pure Tier B ONNX saved to {out_path}")

if __name__ == '__main__':
    train_tier_b_pure()