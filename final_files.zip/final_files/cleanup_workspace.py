import os
from pathlib import Path

def clean_workspace():
    # This is the "Whitelist". Only these elite files will survive the purge.
    # It includes your pure scripts, datasets, final models, and AWS files.
    FILES_TO_KEEP = {
        # Data & Maps
        "pure_cicids2017.parquet",
        "universal_label_map.json",
        "gate_features.json",
        "gate_classifier.json",
        
        # Training Scripts
        "clean_data_final.py",
        "train_tier_b_pure.py",
        "train_tier_c_pure.py",
        
        # Final ONNX Models
        "gate_classifier.onnx",
        "tier_b_rf_pure.onnx",
        "tier_c_xgboost_pure.onnx",
        
        # Cloud API Files (if you created them here)
        "api_server.py",
        "Procfile",
        "requirements.txt",
        "cybershield_api.zip",
        
        # This script itself
        "cleanup_workspace.py"
    }

    folder_path = Path.cwd()
    deleted_count = 0

    print("🧹 Initiating CyberShield Workspace Purge...\n")

    for file_path in folder_path.iterdir():
        if file_path.is_file():
            if file_path.name not in FILES_TO_KEEP:
                try:
                    os.remove(file_path)
                    print(f"🗑️ Deleted Legacy File: {file_path.name}")
                    deleted_count += 1
                except Exception as e:
                    print(f"⚠️ Could not delete {file_path.name}: {e}")

    print("\n" + "="*50)
    print(f"✅ PURGE COMPLETE: Removed {deleted_count} unnecessary files.")
    print("Your workspace now contains ONLY the final, enterprise-grade architecture.")
    print("="*50)

if __name__ == "__main__":
    clean_workspace()