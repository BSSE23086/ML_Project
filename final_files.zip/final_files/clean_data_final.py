import pandas as pd
from pathlib import Path
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(message)s')

def perform_final_scrub():
    data_path = Path.cwd() / "cleaned_cicids2017.parquet"
    
    logging.info("Loading corrupted dataset...")
    df = pd.read_parquet(data_path)
    initial_rows = len(df)
    
    # 1. KILL THE LEAK
    if 'Is_Attack' in df.columns:
        df = df.drop(columns=['Is_Attack'])
        logging.info("CRITICAL FIX: 'Is_Attack' cheat-code column completely removed.")
        
    # 2. DROP EXACT DUPLICATES (Prevent memorization)
    df = df.drop_duplicates()
    final_rows = len(df)
    dropped = initial_rows - final_rows
    logging.info(f"CRITICAL FIX: Dropped {dropped} exact duplicate rows.")
    
    # 3. FIX LABEL ENCODING ISSUES (Some files have weird unicode characters)
    # We map them to clean strings that match our JSON map
    clean_map = {
        'Web Attack  Brute Force': 'Web Attack - Brute Force',
        'Web Attack  Sql Injection': 'Web Attack - Sql Injection',
        'Web Attack  XSS': 'Web Attack - XSS'
    }
    df['Label'] = df['Label'].replace(clean_map)
    
    # Export the pure, scrubbed dataset
    out_path = Path.cwd() / "pure_cicids2017.parquet"
    df.to_parquet(out_path, index=False)
    logging.info(f"✅ Pure dataset saved as {out_path} ({final_rows} rows). Ready for rigorous training.")

if __name__ == "__main__":
    perform_final_scrub()